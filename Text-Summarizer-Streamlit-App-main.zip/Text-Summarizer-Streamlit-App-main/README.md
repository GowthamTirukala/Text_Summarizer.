Do these before you start the project 
1.install visual studio code from browser from the below link 
https://code.visualstudio.com/
2.install python 3.11.6 from microsoft store i recommend this because it is the stable version 
3.After installing these two now open this file in vscode
4.After opening the file open command prompt now install the following libraries 
*.Library              Commmand
*.Streamlit----------- pip install streamlit  (for web)
*.txtai--------------- pip install txtai      (for summarizing the txt)
*.PyPDF2-------------- pip install PyPDF2     (for handling and extracting text from the pdf)
*.Docx---------------- pip install python-docx(for handlig and extracting text from docx)
5. now click the run button on left side top after opening app.py
6. while the execution u need to open terminal window which will be below by default
7. During execution u can watch something like this in terminal window :
 Warning: to view this Streamlit app on a browser, run it with the following
  command:

    streamlit run c:/Users/tiruk/Desktop/Text-Summarizer-Streamlit-App-main/Text-Summarizer-Streamlit-App-main/app.py [ARGUMENTS]
PS C:\Users\tiruk\Desktop\Text-Summarizer-Streamlit-App-main\Text-Summarizer-Streamlit-App-main
8. streamlit run c:/Users/tiruk/Desktop/Text-Summarizer-Streamlit-App-main/Text-Summarizer-Streamlit-App-main/app.py you need to copy this text and paste in terminal window.
9.Now u can see something like this:
  You can now view your Streamlit app in your browser.

  Local URL: http://localhost:8501
  Network URL: http://172.25.35.92:8501
10.Just copy paste the Local URL in the web browser u can use the website


